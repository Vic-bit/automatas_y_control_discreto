function PlotDock()
figure;
xlabel("X (m)");
ylabel("Y (m)");
hold on;
% dock base
rectangle('Position',[-30,-20, 30 + 1.5, 20], 'FaceColor', 'k', 'LineWidth', 2);
% water
rectangle('Position',[1.5,-20, 1.5 + 0.8, 10], 'FaceColor', 'b');
rectangle('Position',[50,-20, 10, 10], 'FaceColor', 'b');
% ship
line([3.8, 3.8, 50, 50], [0, -20, -20, 0], 'Color', 'g', 'LineWidth', 5);
% sill bean
rectangle('Position',[-1.5,0, 3, 15], 'FaceColor', 'k', 'LineWidth', 2);

% Crane
rectangle('Position',[-30,45, 80, 5], 'FaceColor', 'y', 'LineWidth', 2);

end