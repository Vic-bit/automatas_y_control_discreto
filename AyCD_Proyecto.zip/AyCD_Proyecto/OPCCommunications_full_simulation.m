function output = OPCCommunications_full_simulation(input)
    % not including "map"
%     ReadKeys = [];
    WriteKeys = ["currentX" "currentL"];
   
    if (size(input) ~= size(WriteKeys))
        input = zeros(size(WriteKeys));
    end
    
    % connection Variables
    persistent initServer;
    persistent initNodes;
    persistent client;
    % nodes
%     persistent ReadNodes;
    persistent WriteNodes;

    % initializate variables
    if(isempty(initServer))
        initServer = 0;
        initNodes = 0;
    end
    
    % attemp connection to opcua server
    if (initServer == 0)
        server = opcuaserverinfo('192.168.1.103');
        client = opcua(server);
        client.connect();
        initServer = 1;
        disp("Connected to OPCUA server succesfully!");
    end
    
    % init network get/set
    if (client.isConnected && initNodes == 0)
        % read
        % Init ReadNodes type
%         ReadNodes = client.getNamespace().findNodeByName(ReadKeys(1), "-once");
%         for i = 1: size(ReadKeys, 2)
%             ReadNodes(i) = client.getNamespace().findNodeByName(ReadKeys(i), "-once");
%         end
        disp("Initialized OPCUA ReadNodes!");
        % write
        % Init WriteNodes type
        WriteNodes = client.getNamespace().findNodeByName(WriteKeys(1), "-once");
        for i = 1: size(WriteKeys, 2)
            WriteNodes(i) = client.getNamespace().findNodeByName(WriteKeys(i), "-once");
        end
        disp("Initialized OPCUA WriteNodes!");
        % success
        initNodes = 1;
    end
    
    if (client.isConnected == 1 && initNodes == 1)
        % read data
%         output = zeros(size(ReadNodes));
        output = zeros(1,1);
%         for i = 1: size(ReadNodes, 2)
%                 output(i) = double(ReadNodes(i).readValue());
%         end
        % write data
        for i = 1: size(WriteNodes, 2)
            WriteNodes(i).writeValue(input(i));
        end
    end
end

