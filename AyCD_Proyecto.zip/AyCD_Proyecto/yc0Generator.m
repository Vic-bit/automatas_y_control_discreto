function [map, y, maxHeight] = yc0Generator(heightMap, x, modify)
[~, invalidPositions, container_height, ~] = yc0ConfigData();

if (modify == 0)
elseif (modify == 1)
    heightMap = addContainer(heightMap, position2index(x, heightMap));
elseif (modify == -1)
    heightMap = removeContainer(heightMap, position2index(x, heightMap));
end

y = heightMap(position2index(x, heightMap)) * container_height;
if (position2index(x, heightMap) == 12)
    y = 15;
end
if (position2index(x, heightMap) == 13)
    y = 20;
end
if (position2index(x, heightMap) > max(invalidPositions) - 1)
    y = y - 20;
end

map = heightMap;
maxHeight = max(heightMap) * container_height;

end


function index = position2index(x, map)
    [~, ~, ~, container_width] = yc0ConfigData();
    tempMap = [1: size(map, 2)] * container_width - 30;
    tempMap = tempMap - x;
    
    [~,index] = min(abs(tempMap));
end

function newMap = addContainer(map, index)
    [~, ~, ~, ~] = yc0ConfigData();
    if isDeployablePosition(index)
        map(index) = map(index) + 1;
    end
    newMap = map;
end

function newMap = removeContainer(map, index)
     [~, ~, ~, ~] = yc0ConfigData();
    if isDeployablePosition(index)
        map(index) = map(index) - 1;
    end
    newMap = map;
end

function isValid = isDeployablePosition(index)
    [~, invalidPositions, ~, ~] = yc0ConfigData();
    if (ismember(index, invalidPositions))
        isValid = 0; 
    else 
        isValid = 1;
    end
end