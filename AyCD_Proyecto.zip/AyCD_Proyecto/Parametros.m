% Parametros
clear, clc;
clear OPCCommunications;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constant Power
Ph_nom = 956150;
ml_med = 32500;

% yc0Generator Parameters
mapSize = 32;
invalidPositions = [12, 13];

% Work Parameters
position_tolerance = 0.05;
% Condiciones Iniciales
% Carro
xt0 = -10; %debe ser variable
xt_min = -30;
xt_max = 50;
dxt_max = 4;
ddxt_max = 1;

yt0 = 45;
% ylo no puede ser menor a yc0(x,t)
yl0 = 10; % debe ser variable
xl0 = xt0; % debe ser variable
yl_min = -20;
yl_max = 40;
dyl_max = 1.5;
dyl_max_no_cargo = 3.0;
ddyl_max = 1;

container_height = 3.0;
container_width = 2.5;

lh0 = yt0 - yl0;

ysb = 15;
ml0 = 15000;
ml_min = 2000;
ml_max = 50000;
ml  = (ml_max-ml_min)*rand(1) + ml_min;
% ml = 50000;

% fines de carrera
% re_top = yl_max - container_height;
re_top = yl_max;
re_bottom = yl_min + container_height;
re_right= xt_max - container_width / 2;
re_left= xt_min + container_width / 2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Traslación Carro

%carro_motor = DynamicSystem;
%carro_motor.J = 10.0;
%carro_motor.b = 0.0630;

% Momento de intercia del eje del motor
Jm = 10.0;
% Fricción viscosa del eje del motor
bm = 0.0630;

% Masa total del Carro
mt = 50000;

% Momento de inercia de la rueda del carro
Jw = 2.0;
% Fricción de la rueda del carro
%bw = 30e3;

% Radio de la rueda del carro
Rw = 0.5;
% Relación de transmisión del eje del motor al eje de la rueda
rt = 15.0;

% Masa equivalente sistema traslación carro
Meq_t = mt + (Jw + Jm * rt^2)/Rw^2;
% Fricción equivalente del sistema traslación del carro
%beq_t = (bw + bm * rt^2)/Rw^2;
%beq_t = 30.0;
beq_t = (30.0 * rt^2)/Rw^2;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Izaje Carga
% Momento de inercia del eje del motor del sistema de izaje
Jmh = 30.0;
% Fricción viscoza del eje del motor del sistema de izaje
bmh = 0.0630;
% Relación de trasnmisión del eje del motor al eje del tambor del sistema
% de izaje
rth = 30.0;
% Momento de intercia del tambor del sistema de izaje
Jd = 8.0;
% Masa del cable del sistema de izaje
Mh = 0;
% Fricción del cable del sistema de izaje
bh = 0;
% Radio del tambor del sistema de izaje
Rd = 0.75;
% Masa equivalente sistema de izaje
Meq_h = ((Jmh*rth^2 + Jd)/Rd^2 + Mh);
% Fricción equivalente sistema de izaje
%beq_h = (bmh*rth^2 + bd)/Rd^2;
%beq_h = 18;
beq_h = (18.0 * rth^2)/Rd^2;
% Fricción del tambor del sistema de izaje
%bd = beq_h*Rd^2 - bmh*rth^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Carga
% Modulo elástico cable de carga
Kw = 1800e3;
% Fricción interna del cable de la carga
b_cable = 30.0e3;
% Aceleración de la gravedad
g = 9.80665;

delta_l0=(ml+ml0)*g/Kw;

yl0 = yt0 - lh0 - delta_l0;

%l = Fw0/Kw + lh0;
% longitud del cable sin estirar
% lh = 1;
% Altura del carro (cosntante puesto que se encuentra sobre la pluma)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Carga apoyada
% Rigidez vertical contenedores?
Kcy = 1.3e6;
% Fricción vertical contacto?
bcy = 10000;
% Fricción horizontal contacto? 
bcx = 1000;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tau = 1/1000;
% Controlador movimiento carro
carro_polo_1 = beq_t/Meq_t;
carro_polo_2 = 0;

% Polo controlador sistema de traslacion carro
% wpos = 10 * carro_polo_1;
wpos = 5 * carro_polo_1;
% Coeficiente comportamiento (sub amortiguado)
% n = 2.5;
n = 4;
% Ganancia derivativa del controlador traslacion carro
bat = (n*wpos*Meq_t);
% Ganancia proporcional del controlador traslacion carro
ksat = (n*wpos^2*Meq_t);
% Ganancia integral del controlador traslacion carro
ksiat = (wpos^3*Meq_t);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Controlador sistema izaje
izaje_polo_1 = beq_h/Meq_h;
izaje_polo_2 = 0;
% Polo controlador sistema izaje
wizaje = 10 * izaje_polo_1;
% Factor de comportamiento (sub amortiguado)
% n = 2.5;
n = 3;
% Ganancia derivativa del controlador sistema izaje
bah = (n*wizaje*Meq_h);
% Ganancia derivativa del controlador sistema izaje
ksah = (n*wizaje^2*Meq_h);
% Ganancia derivativa del controlador sistema izaje
ksiah = (wizaje^3*Meq_h);
