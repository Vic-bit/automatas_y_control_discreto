function [mapSize, invalidPositions, container_height, container_width] = yc0ConfigData()
    mapSize = 32;
    invalidPositions = [12, 13];
    container_height = 3.0;
    container_width = 2.5;
end