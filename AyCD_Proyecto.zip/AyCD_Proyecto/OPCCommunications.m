function output = OPCCommunications(input)
    % not including "map"
    ReadKeys = ["XTarget", "YTarget", "operationMode", "YC0", "ml", "Tm", "Tmh", "y"];
    WriteKeys = ["currentX", "currentL", "currentTheta", "currentFw", "dxt","dlh","dxt_manual","dyl_manual", "reXMax", "reXMin", "reYMax", "reYMin","re_right_ult","re_left_ult","re_top_ult","re_bottom_ult"];
    
    if (size(input) ~= size(WriteKeys))
        input = zeros(size(WriteKeys));
    end
    
    % connection Variables
    persistent initServer;
    persistent initNodes;
    persistent client;
    % nodes
    persistent ReadNodes;
    persistent WriteNodes;

    % initializate variables
    if(isempty(initServer))
        initServer = 0;
        initNodes = 0;
    end
    
    % attemp connection to opcua server
    if (initServer == 0)
        server = opcuaserverinfo('localhost');
        client = opcua(server);
        client.connect();
        initServer = 1;
        disp("Connected to OPCUA server succesfully!");
    end
    
    % init network get/set
    if (client.isConnected && initNodes == 0)
        % read
        % Init ReadNodes type
        ReadNodes = client.getNamespace().findNodeByName(ReadKeys(1), "-once");
        for i = 1: size(ReadKeys, 2)
            ReadNodes(i) = client.getNamespace().findNodeByName(ReadKeys(i), "-once");
        end
        disp("Initialized OPCUA ReadNodes!");
        % write
        % Init WriteNodes type
        WriteNodes = client.getNamespace().findNodeByName(WriteKeys(1), "-once");
        for i = 1: size(WriteKeys, 2)
            WriteNodes(i) = client.getNamespace().findNodeByName(WriteKeys(i), "-once");
        end
        disp("Initialized OPCUA WriteNodes!");
        % success
        initNodes = 1;
    end
    
    if (client.isConnected == 1 && initNodes == 1)
        % read data
        output = zeros(size(ReadNodes));
        for i = 1: size(ReadNodes, 2)
                output(i) = double(ReadNodes(i).readValue());
        end
        % write data
        for i = 1: size(WriteNodes, 2)
            WriteNodes(i).writeValue(input(i));
        end
    end
end

